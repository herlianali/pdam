@extends('layout.app')
@section('title', 'Jenis Panggilan Dinas')

@push('css')
    <link rel="stylesheet" href="{{ asset('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css') }}">
@endpush

@section('namaHal', 'Master')
@section('breadcrumb')
<ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="#">Master</a></li>
    <li class="breadcrumb-item active">Jenis Panggilan Dinas</li>
</ol>
@endsection

@section('content')
<section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Jenis Panggilan Dinas</h3>
                            <button type="button" class="btn btn-sm btn-info float-right" data-toggle="modal" data-target="#tambah"><i class="fas fa-plus-circle"></i> Buat</button>
                        </div>
                        <div class="card-body">
                        <a href="{{ route('printpanggilanDinas') }}" class="btn btn-sm btn-success float-right"><i class="fas fa-print"></i> Cetak</a>
                        <br>
                        &nbsp;
            <table id="table" class="table table-bordered table-responsive-md table-condensed">
                    <thead>
                    <tr>
                        <th width="10%">No </th>
                        <th width="20%">Jenis PDINAS</th>
                        <th width="50%">Keterangan</th>
                        <th width="20%">Aksi</th>
                    </tr>
                    </thead>
                <tbody>
                    @foreach ($pDinass as $pDinas )
                    <tr>
                        <td>{{ ++$i }}</td>
                        <td>{{ $pDinas->jp_dinas }}</td>
                        <td>{{ $pDinas->keterangan }}</td>
                        <td>
                        <button type="submit" class="btn btn-xs btn-danger " onclick="deletePanggilanDinas({{ $pDinas->id }})"><i class="fas fa-trash-alt"></i> Hapus</button>
                        <button type="button" class="btn btn-xs btn-success " data-toggle="modal" data-target="#edit"><i class="fas fa-edit"></i> Edit</button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
</section>
{{-- Tambah Form --}}
    @include('master.panggilanDinas.create')
{{-- Edit Form --}}
    @include('master.panggilanDinas.edit')
  
@endsection

@push('js')
    <script src="{{ asset('assets/plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables-buttons/js/dataTables.buttons.min.js') }}"></script>
    <script>
        $(function () {
            $('#table').DataTable({
                "paging": true,
              //  "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
             //   "autoWidth": false,
             //   "responsive": true,
                "pageLength": 5
            });
        });

       function valueing() {
            if(document.getElementById('kode').value==="" || document.getElementById('keterangan').value==="") {
                document.getElementById('batal').disabled = true
                document.getElem entById('simpan').disabled = true
            }else{
                document.getElementById('batal').disabled = false
                document.getElementById('simpan').disabled = false
            }
        }

            function deletePanggilanDinas (id) {
            swal.fire({
                title: "Hapus Data?",
                icon: 'question',
                text: "Apakah Anda Yakin Ingin Menghapus",
                type: "warning",
                showCancelButton: !0,
                confirmButtonColor: "#e74c3c",
                confirmButtonText: "Iya",
                cancelButtonText: "Tidak",
                reverseButtons: !0
            }).then(function (e) {
                if (e.value === true) {
                    let token = "{{ csrf_token() }}"
                    let _url = `/pDinass/${id}`
                    console.log(_url)

                    $.ajax({
                        type: 'DELETE',
                        url: _url,
                        data: {_token: token},
                        success: function (resp) {
                            if (resp.success) {
                                swal.fire("Selesai!", resp.message, "Berhasil");
                                location.reload();
                            }else{
                                swal.fire("Gagal!", "Terjadi Kesalahan.", "error");
                            }
                        },
                        error: function(resp) {
                            swal.fire("Gagal!", "Terjadi Kesalahan.", "error" )
                        }
                    })
                }else{
                    e.dismiss;
                }
            }, function(dismiss) {
                return false;
            });
        }
    </script>
@endpush
