<?php

namespace App\Http\Controllers;

use App\Models\PanggilanDinas;
use Illuminate\Http\Request;

class PanggilanDinasController extends Controller
{
    public function index()
    {
      
        $pDinass = PanggilanDinas::all();
        return view('master.panggilanDinas.index', compact('pDinass'))->with('i');
   
    }

  
    public function create()
    {
        return view('master.panggilanDinas.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'jp_dinas'           => 'required',
            'keterangan'         => 'required|max:50',
        ]);

        $pDinas = PanggilanDinas::updateOrCreate(['id' => $request->id], [
            'jp_dinas'           => $request->jp_dinas,
            'keterangan'         => $request->keterangan,
        ]);

        return response()->json(['code'=>50, 'message'=>'Jenis Panggilan Dinas Created Successfully', 'data' =>$pDinas], 50);
    }

   
    public function show($id)
    {
        $pDinas = PanggilanDinas::find($id);
        return response()->json($pDinas);
    }

   
    public function edit($id)
    {
        
        return view('master.panggilanDinas.edit');
    }

 
    public function update(Request $request, $id)
    {
        //
    }


    public function destroy($id)
    {
        $pDinas = PanggilanDinas::find($id)->delete();
        return response()->json(['success'=> 'Jenis Panggilan Dinas Berhasil Dihapus']);
    }
    public function print()
    {
        return view('master.panggilanDinas.print');
    }
}
